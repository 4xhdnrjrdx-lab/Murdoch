CREATE TABLE `answers` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`person` text NOT NULL,
	`stage` text NOT NULL,
	`first_choice` integer NOT NULL,
	`first_correct` integer NOT NULL,
	`solved` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `run_decision` ON `answers` (`run_id`,`person`,`stage`);--> statement-breakpoint
CREATE TABLE `rounds` (
	`id` text PRIMARY KEY NOT NULL,
	`active` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_active_round` ON `rounds` (`active`) WHERE "rounds"."active" = 1;--> statement-breakpoint
CREATE TABLE `runs` (
	`id` text PRIMARY KEY NOT NULL,
	`round_id` text NOT NULL,
	`team` text NOT NULL,
	`slot` text NOT NULL,
	`token_hash` text NOT NULL,
	`started_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`finished_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `round_slot` ON `runs` (`round_id`,`slot`);