import {activeRound,database,guard,json} from '../../server';
export const dynamic='force-dynamic';
export async function GET(){return guard(async()=>{const r=await activeRound();const taken=await database().prepare("SELECT team FROM runs WHERE round_id = ? AND team != 'Others'").bind(r.id).all<{team:string}>();return json({roundId:r.id,taken:taken.results.map(x=>x.team)})})}
