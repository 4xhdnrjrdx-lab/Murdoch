import {activeRound,body,database,guard,hash,json,originCheck,ApiError,runState} from '../../server';
export async function POST(req:Request){return guard(async()=>{
 originCheck(req);const b=await body(req);
 if(!['Team 1','Team 2','Team 3','Others'].includes(b.team))throw new ApiError('Choose your team.');
 if(typeof b.token!=='string'||!/^[a-zA-Z0-9-]{30,100}$/.test(b.token))throw new ApiError('Invalid device session.');
 const round=await activeRound(),db=database(),tokenHash=await hash(b.token);
 const prior=await db.prepare('SELECT * FROM runs WHERE round_id = ? AND token_hash = ?').bind(round.id,tokenHash).first<any>();
 if(prior)return json({state:await runState(prior)});
 let displayName:string|null=null;
 if(b.team==='Others'){
  if(typeof b.displayName!=='string')throw new ApiError('Enter a name or label for Others.');
  displayName=b.displayName.replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g,'').trim();
  if(!displayName||displayName.length>40)throw new ApiError('Use a name or label from 1 to 40 characters.');
 }
 const id=crypto.randomUUID(),slot=b.team==='Others'?id:b.team,now=new Date().toISOString();
 const n=await db.prepare('SELECT COUNT(*) AS n FROM runs WHERE round_id = ?').bind(round.id).first<{n:number}>();
 if((n?.n??0)>100)throw new ApiError('This session is full.',409);
 try{await db.prepare('INSERT INTO runs (id, round_id, team, display_name, slot, token_hash, started_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(id,round.id,b.team,displayName,slot,tokenHash,now,now).run()}
 catch{throw new ApiError('That team has already joined. Use its original phone or choose Others.',409)}
 return json({state:await runState({id,round_id:round.id,team:b.team,display_name:displayName,slot,token_hash:tokenHash,started_at:now,updated_at:now,finished_at:null})});
})}
