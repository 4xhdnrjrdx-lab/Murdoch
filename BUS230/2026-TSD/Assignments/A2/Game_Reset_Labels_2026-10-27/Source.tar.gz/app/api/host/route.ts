import {activeRound,database,guard,json,requireHost,body,originCheck,ApiError} from '../../server';
export const dynamic='force-dynamic';
export async function GET(){return guard(async()=>{
 await requireHost();const round=await activeRound();
 const all=await database().prepare('SELECT id,team,display_name,started_at,updated_at,finished_at FROM runs WHERE round_id = ? ORDER BY started_at').bind(round.id).all<any>();
 const a=await database().prepare('SELECT a.run_id,a.person,a.stage,a.first_choice,a.first_correct,a.solved FROM answers a JOIN runs r ON a.run_id = r.id WHERE r.round_id = ?').bind(round.id).all<any>();
 return json({roundId:round.id,createdAt:round.created_at,runs:all.results.map(r=>{const answers=a.results.filter(x=>x.run_id===r.id);return {...r,progress:answers.filter(x=>x.stage==='action'&&x.solved===1).length,errors:answers.filter(x=>!x.first_correct).length,answers:answers.map(({run_id,...x})=>x)}}),checkedAt:new Date().toISOString()});
})}
export async function POST(req:Request){return guard(async()=>{
 originCheck(req);await requireHost();const b=await body(req),active=await activeRound();
 if(b.roundId!==active.id)throw new ApiError('Session changed. Refresh the host page first.',409);
 const db=database();
 if(b.action==='new-session'){
  if(b.confirmReset!==true)throw new ApiError('Confirm the reset before starting a new session.');
  const id=crypto.randomUUID();
  const changed=await db.batch([
   db.prepare('UPDATE rounds SET active = 0 WHERE id = ? AND active = 1').bind(active.id),
   db.prepare('INSERT INTO rounds (id, active, created_at) SELECT ?, 1, ? WHERE NOT EXISTS (SELECT 1 FROM rounds WHERE active = 1)').bind(id,new Date().toISOString())
  ]);
  if(changed[1].meta.changes!==1)throw new ApiError('Another host already started a new session. Refresh to continue.',409);
  return json({roundId:id});
 }
 if(b.action==='release-team'&&['Team 1','Team 2','Team 3'].includes(b.team)){
  const r=await db.prepare('SELECT id FROM runs WHERE round_id = ? AND team = ? AND slot = ?').bind(active.id,b.team,b.team).first<{id:string}>();
  if(r)await db.prepare('UPDATE runs SET slot = ?, team = ? WHERE id = ?').bind(r.id,b.team+' (previous attempt)',r.id).run();
  return json({released:true});
 }
 throw new ApiError('Unknown host action.');
})}
