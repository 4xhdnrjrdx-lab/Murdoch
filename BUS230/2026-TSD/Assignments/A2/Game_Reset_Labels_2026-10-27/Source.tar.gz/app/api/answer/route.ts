import {decision,guard} from '../../server';
export async function POST(req:Request){return guard(()=>decision(req))}
