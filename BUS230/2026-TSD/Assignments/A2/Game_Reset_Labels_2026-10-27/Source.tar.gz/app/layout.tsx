import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'Cedar Retail · The manager’s shift',description:'A five-situation BUS230 team activity about managing change.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
