import {getChatGPTUser,chatGPTSignInPath} from '../chatgpt-auth';
import {hostAllowed} from '../server';
import Host from './Host';
export const dynamic='force-dynamic';
export default async function Admin(){const u=await getChatGPTUser();if(!u)return <main className="host-shell"><div className="host-brand">CEDAR RETAIL · HOST</div><h1>Host sign-in</h1><p>Sign in with the account that owns this site to see team results.</p><a className="host-button" href={chatGPTSignInPath('/admin')} target="_top">Sign in with ChatGPT →</a><p><a href="/">← Back to game</a></p></main>;if(!await hostAllowed())return <main className="host-shell"><h1>Host access only</h1><p>This account does not have access to team results.</p><a href="/signout-with-chatgpt?return_to=%2Fadmin" target="_top">Use another account</a></main>;return <Host/>}
