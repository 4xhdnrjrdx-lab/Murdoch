"""Local classroom integration checks. Uses mock sign-in in the supplied portable starter."""
import json,uuid,urllib.request,urllib.error,http.cookiejar,os
from pathlib import Path
BASE=os.environ.get('CEDAR_QA_URL','http://127.0.0.1:8772')
assert urllib.parse.urlparse(BASE).hostname in ('127.0.0.1','localhost'), 'Local QA only'
passed=[]
def check(label,condition):
 assert condition,label
 passed.append(label)
def request(path,data=None,run=None,opener=None,origin=None):
 headers={'Content-Type':'application/json'}
 if data is not None:headers['Origin']=origin or BASE
 if run:headers.update({'Authorization':'Bearer '+run['token'],'X-Run-Id':run['state']['id']})
 req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 try:
  with (opener.open if opener else urllib.request.urlopen)(req,timeout=20) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:
  raw=e.read()
  try:return e.code,json.loads(raw)
  except ValueError:return e.code,{'error':'Non-JSON error response'}
def join(team):
 token=str(uuid.uuid4());code,a=request('/api/join',{'team':team,'token':token});check(team+' joined',code==200);return {'token':token,**a}
code,a=request('/api/host');check('Anonymous host results denied',code==403)
code,a=request('/api/join',{'team':'Others','token':str(uuid.uuid4())},origin='https://unrelated.example');check('Cross-origin write denied',code==403)
code,a=request('/api/session');check('Public session exposes no results',code==200 and set(a)=={'roundId','taken'})
# Local signed-in owner, not a forged production identity header.
jar=http.cookiejar.CookieJar();owner=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar));owner.open(BASE+'/signin-with-chatgpt?return_to=/admin').read()
code,a=request('/api/host',opener=owner);check('Local owner can read host results',code==200)
code,a=request('/api/host',{'action':'new-session','roundId':a['roundId']},opener=owner);check('Owner starts fresh session',code==200)
team=join('Team 1');t2=join('Team 2');t3=join('Team 3');o1=join('Others');o2=join('Others');check('Separate Others attempts',o1['state']['id']!=o2['state']['id'])
code,a=request('/api/join',{'team':'Team 1','token':str(uuid.uuid4())});check('Occupied team protected',code==409)
code,a=request('/api/join',{'team':'Team 1','token':team['token']});check('Lost join response safely resumes same run',code==200 and a['state']['id']==team['state']['id'])
code,a=request('/api/answer',{'person':'anna','stage':'action','choice':2},team);check('Action requires investigation',code==409)
code,a=request('/api/finish',{},team);check('Early finish rejected',code==409)
code,a=request('/api/answer',{'person':'anna','stage':'ask','choice':0},team);check('Wrong first answer clearly returned',code==200 and a['correct'] is False)
code,a=request('/api/answer',{'person':'anna','stage':'ask','choice':0},team);check('Repeated request remains one decision',code==200)
key={'anna':(1,2),'omar':(0,1),'mia':(2,0),'leo':(1,2),'sara':(0,1)}
for person in ['sara','leo','mia','omar','anna']:
 for stage,choice in zip(['ask','action'],key[person]):
  code,a=request('/api/answer',{'person':person,'stage':stage,'choice':choice},team)
  check(person+' '+stage+' correct and saved',code==200 and a['correct'] is True)
code,a=request('/api/run',run=team);check('Server restores all five conversations',code==200 and len(a['state']['reviewed'])==5)
code,a=request('/api/finish',{},team);check('Neutral completion genuinely saved',code==200 and a['saved'] is True and a['state']['finished'])
code,a=request('/api/host',opener=owner);row=next(r for r in a['runs'] if r['team']=='Team 1');check('Host sees completed 5/5 and retained first error',row['progress']==5 and row['errors']==1 and row['finished_at'] and len(row['answers'])==10)
check('Three teams and multiple Others visible',len(a['runs'])==5)
code,b=request('/api/host',{'action':'release-team','roundId':a['roundId'],'team':'Team 1'},opener=owner);check('Host can release occupied team',code==200)
retry=join('Team 1');check('Released team starts distinct attempt',retry['state']['id']!=team['state']['id'])
code,a=request('/api/host',opener=owner);check('Original team attempt retained',any(r['team']=='Team 1 (previous attempt)' and r['errors']==1 for r in a['runs']))
code,b=request('/api/host',{'action':'new-session','roundId':a['roundId']},opener=owner);check('Owner archives test session',code==200)
code,a=request('/api/run',run=t2);check('Old run cannot enter new session',code==409)
code,a=request('/api/answer',{'person':'anna','stage':'ask','choice':1},t3);check('Old session cannot write new results',code==409)
code,a=request('/api/host',opener=owner);check('Fresh host session has no attempts',code==200 and a['runs']==[])
print(json.dumps({'passed':passed,'count':len(passed),'environment':'local portable preview; mock ChatGPT owner sign-in; separate D1 storage'},indent=2))
