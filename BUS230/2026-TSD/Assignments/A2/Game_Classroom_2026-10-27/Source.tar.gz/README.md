# Cedar Retail — classroom game

BUS230 fictional teaching activity. Five colleagues in any order, two decisions each.
One device per team. Team 1–3 are reserved once joined; Others permits separate anonymous additional attempts.

The public player route is `/`. `/admin` and `/api/host` require the Sites ChatGPT identity whose email matches the server runtime `ADMIN_EMAIL`. Anonymous requests and other signed-in accounts are denied. Public result APIs return only the authorized run's progress; the private host endpoint contains the first-answer error counts. API writes use a per-attempt capability, stored as a hash in D1. Correctness is calculated on the server. No participant names, prizes, public scores, or leaderboards.

## Development

Use the supplied Sites runtime workflow. `npm run dev -- --hostname 127.0.0.1 --port 8772`.
For a local host test only, ignored `.dev.vars` can set `ADMIN_EMAIL=seedy@sites.test`; the starter's portable local sign-in supplies that test identity. This mock identity is not included in production.

Schema: `db/schema.ts`, generated migrations in `drizzle/`. Never edit an applied migration. The hosting manifest preserves the existing project ID and provisions `DB`.

`python3 tests/api-qa.py` is a local integration test. It creates synthetic runs, checks first-answer retention, team locking, multiple Others, early finish rejection, host authorization and session archival. It starts a fresh local session at the end. Do not run it against production.

First responses are immutable; corrected answers only mark the decision solved. Results are saved before the player sees feedback. A failed network request allows retry without resetting its initial response. Refresh resumes the run on the same browser. If a phone is lost, the host can allow a new attempt; the earlier attempt stays in the host list. Starting a fresh session archives previous results and requires all players to join again.

The old `demo-fragment.html` is retained as source history only. Production is the Vinext Worker under `app/`, with D1 storage and a separately protected host page.
