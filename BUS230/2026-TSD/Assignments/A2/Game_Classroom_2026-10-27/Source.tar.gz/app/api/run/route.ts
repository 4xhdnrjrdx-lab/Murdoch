import {activeRound,authorize,guard,json,runState,ApiError} from '../../server';
export const dynamic='force-dynamic';
export async function GET(req:Request){return guard(async()=>{const r=await authorize(req);if(r.round_id!==(await activeRound()).id)throw new ApiError('A new session has started.',409);return json({state:await runState(r)})})}
